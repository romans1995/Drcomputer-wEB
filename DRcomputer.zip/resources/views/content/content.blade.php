@extends('master')
@section('main_content')
<div class="row">
  @foreach($contents as $content)
  <div class="col-12">
    <h4>{{$content->ctitle }}</h4>
    <p>{!! $content->carticle !!}}</p>
  </div>
  @endforeach
</div>
@endsection