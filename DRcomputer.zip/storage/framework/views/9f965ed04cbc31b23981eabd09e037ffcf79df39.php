<?php $__env->startSection('main_content'); ?>
<style>
  .form-control {
    display: block;
    width: 100%;
    height: 40px;
    padding: 1px 2px;
    font-size: 14px;
    margin-bottom: 23px;

  }
</style>

<img style="padding-left:368px" src=" <?php echo e(asset('images/dog2.jpg')); ?>" alt="computer dog">




<!-- Start page content -->
<div id="page-content" class="page-wrapper">

  <!-- LOGIN SECTION START -->

  <!-- new-customers -->

  <div class="col-md-6">
    <div class="new-customers">
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>

      <form action="" method="POST" novalidate="novalidate" autocomplete="off">
        <?php echo csrf_field(); ?>
        <h6 class="widget-title border-left mb-50">לקוח חדש</h6>
        <div class="login-account p-30 box-shadow">
          <div class="row">
            <div class="col-sm-8">
              <label for="name"></label>
              <input value="<?php echo e(old('firstName')); ?>" type="text" name="firstName" id="firstName" class=""
                placeholder="שם פרטי">
            </div>
            <div class="col-sm-8">
              <input value="<?php echo e(old('lastName')); ?>" type="text" name="lastName" id="lastName" class=""
                placeholder="שם משפחה">
            </div>

            <div class="row">
              <div id="city" class="col-sm-8  ">

                <select name="city" class="custom-select">
                  <option value="defalt">עיר</option>
                  <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($c->id); ?>"><?php echo e($c->city); ?></option>


                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

              </div>
            </div>


            <div class="row">
              
                <div class="col-sm-8">
                  <input type="text" class="phone" name="phone" id="phone" type="phone" class="billing-details p-30"
                    placeholder="מס פלאפון">
                </div>
              </div>
            </div>

            <div class="row">
             
                <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email" class="col-sm-6"
                placeholder="Email address here...">
              </div>
              <div class="row">
                <div class="">
                  <input name="password" id="password" class="form-control" type="password" placeholder="סיסמה">
                </div>
              </div>
              <div class="row">
               
                  <input name="password_confirmation" id="password-confirmation" class="form-control" type="password"
                    placeholder="אימות סיסמה">
                </div>
              </div>

              <button class="submit-btn-1 mt-20 btn-hover-1" type="submit" value="register">הרשם</button>
            </div>
          </div>
          <div class="col-md-6">
            <button class="submit-btn-1 mt-20 btn-hover-1 f-right" type="reset">למחוק הכל!</button>
          </div>
        </div>
    </div>
    </form>
  </div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/forms/signup.blade.php ENDPATH**/ ?>