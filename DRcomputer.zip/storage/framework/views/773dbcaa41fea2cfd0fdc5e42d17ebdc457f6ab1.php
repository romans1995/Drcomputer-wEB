<?php $__env->startSection('main_content'); ?>


<div class="by-brand-section mb-80">
  <?php if($categories): ?>
  <div class="container">

    <div class="row">
      
      
      <h2 class="uppercase">By categories</h2>
      <h6>There are many variations of passages of categories available,</h6>
    </div>
  </div>
</div>


<div class="by-brand-product">
  <div class="row active-by-brand slick-arrow-1">
    <!-- single-brand-product start -->
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xs-6">
      <div class="single-brand-product">
        <a hight="370px" width="300px" href="<?php echo e(url('shop/'.$category['curl'])); ?>"><img
            src="<?php echo e(asset('images/' . $category['cimage'])); ?>" alt="<?php echo e($category['cname']); ?>"></a>
        <h3 class="brand-title text-gray">
          <a href="<?php echo e(url('shop/'.$category['curl'])); ?>"><?php echo e($category['cname']); ?></a>
        </h3>

      </div>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
    <div class="col-12">
      <p><i>sorry,we Dont have Items here :(</i></p>
    </div>
    <?php endif; ?>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/categories.blade.php ENDPATH**/ ?>