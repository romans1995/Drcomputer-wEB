<?php $__env->startSection('cms_content'); ?>
<style>
  .form-control {
    padding: 0px 1px;
  }

  .col-sm-8 {
    width: 102.666667%;
  }

  .error {
    float: right;
  }

  .row {

    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: -15px;
    margin-left: -1px;
    margin-bottom: 20px;
  }
</style>





<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Add New User</h1>





</div>
<div class="error">
  <?php if($errors->any()): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
</div>
<div class="col-md-8">
  <div class="row">

    <div class="col-md-8">
      <form action="<?php echo e(url('cms/users')); ?>" method="POST" enctype="multipart/form-data" novalidate="novalidate"
        autocomplete="off">


        <div class="login-account  box-shadow">
          <div class="row">
            <div class="form-froup">

              <label for="name"></label>
              <input value="<?php echo e(old('firstName')); ?>" type="text" name="firstName" id="firstName"
                class="form-control col-sm-8" placeholder="שם פרטי">
              <?php echo csrf_field(); ?>
            </div>
          </div>

          <div class="row">
            <div class="form-froup ">
              <input value="<?php echo e(old('lastName')); ?>" type="text" name="lastName" id="lastName" class="form-control col-sm-8"
                placeholder="שם משפחה">

            </div>
          </div>

          <div class="row">

            <select id="city" class="form-control " name="city" class="custom-select col-sm-8">
              <option value="defalt">עיר</option>
              <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option <?php if(old('city_id')==$c->id): ?> selected="selected" <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->city); ?>

              </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>


          <div class="row">
            <div class="form-froup ">
              <input value="<?php echo e(old('phone')); ?>" type="text" class="phone col-sm-8" name="phone" id="phone" type="phone"
                class="form-control" placeholder="מס פלאפון">
            </div>
          </div>

          <div class="row">
            <div class="form-froup ">
              <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email" class="form-control col-sm-8"
                placeholder="אימייל">
              <div>
                <div>

                  <div class="row">
                    <div class="form-froup">
                      <input name="password" id="password" class="form-control col-sm-8" type="password"
                        placeholder="סיסמה">
                      <input name="password_confirmation" id="password-confirmation" class="form-control"
                        type="password" placeholder="אימות סיסמה">
                      <div>
                        <div>

                          <div class="row">
                            <div class="form-froup col-sm-8">
                              <label for="categorie_id">Permission</label>
                              <select value="<?php echo e(old('permission')); ?>" class="form-control" name="permission"
                                id="permission">
                                <option value="<?php echo e(old('permission')); ?>">Choose permission</option>
                                <?php $__currentLoopData = $per; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>">
                                  <?php echo e($p->Kind); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                          </div>
                          <input type="submit" value="Create User" name="submit" class="btn btn-primary">
                          <a class="btn btn-secondary" href="<?php echo e(url('cms/users')); ?>">Cancel</a>




      </form>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/create_user.blade.php ENDPATH**/ ?>