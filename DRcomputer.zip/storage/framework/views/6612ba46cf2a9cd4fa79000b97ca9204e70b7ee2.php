<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Products</h1>
</div>
<p><a href="<?php echo e(url('cms/products/create')); ?>" class="btn btn-primary"><i class="fas fa-plus-circle"></i>Add new
    Product</a>
</p>
<?php if($products): ?>
<table class="table table-bordered mt-5">
  <thead>
    <tr>
      <th>Product title</th>
      <th>Product Lead Image</th>
      <th>Updated At</th>
      <th>Operations</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($product['ptitle']); ?></td>
      <td><img width="50" src="<?php echo e(asset('images/'.$product['pimage'])); ?>"></td>
      <td><?php echo e(date('d/m/Y H:i:s',strtotime($product['updated_at']))); ?></td>
      <td>
        <a href="<?php echo e(url('cms/products/' . $product['id'] . '/edit')); ?>"><i class="fas fa-pen"></i>Edit</a>|
        <a href="<?php echo e(url('cms/products/'.$product['id'])); ?>"><i class="fas fa-eraser"></i>Delete</a>

      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/products.blade.php ENDPATH**/ ?>