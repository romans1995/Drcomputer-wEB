<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Edit this Content</h1>

</div>
<div class="row">
  <div class="col-md-6">
    <form action="<?php echo e(url('cms/content/' . $item['id'])); ?>" method="POST" novalidate="novalidate" autocomplete="off">
      <?php echo csrf_field(); ?>
      <?php echo e(method_field('PUT')); ?>

      <div class="form-group">
        <label for="menu-id">Menu Link:</label>
        <select class="form-control" name="menu_id" id="menu_id">

          <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option <?php if($item['menu_id']==$menu['id']): ?> selected="selected" <?php endif; ?> value="<?php echo e($menu['id']); ?> ">
            <?php echo e($menu['link']); ?>:
          </option>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span class="text-danger"><?php echo e($errors->first('menu_id')); ?></span>





      </div>
      <div class="form-group">
        <label for="link">Title:</label>
        <input class="form-control " type="text" name="title" id="title" value="<?php echo e($item['ctitle']); ?>">
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
      </div>
      <div class="form-group">
        <label for="article"> Article:</label>
        <textarea class="form-control" name="article" id="article" cols="30" rows="10"><?php echo e($item['carticle']); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('article')); ?></span>
      </div>
      <input type="submit" value="update Content" name="submit" class="btn btn-primary">
      <a class="btn btn-secondary" href="<?php echo e(url('cms/content')); ?>">Cancel</a>

    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/edit_content.blade.php ENDPATH**/ ?>