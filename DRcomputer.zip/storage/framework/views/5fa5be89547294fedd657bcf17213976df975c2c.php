<?php $__env->startSection('cms_content'); ?>
<style>
  .form-control {
    padding: 0px 1px;
  }

  .col-sm-8 {
    width: 102.666667%;
  }

  .error {
    float: right;
  }

  .row {

    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-right: -15px;
    margin-left: -1px;
  }
</style>


<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Edit User</h1>






  <div class="error">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>
  <div class="col-md-8">
    <div class="row">

      <div class="col-md-8">
        <form action="<?php echo e(url('cms/users/' . $user['id'] . '/edit')); ?>" enctype="multipart/form-data" method="POST"
          novalidate="novalidate" autocomplete="off">
          <?php echo csrf_field(); ?>
          <?php echo e(method_field('PUT')); ?>


          <div class="login-account  box-shadow">
            <div class="row">
              <div class="form-froup">

                <label for="name"></label>
                <input value="<?php echo e($user['firstName']); ?>" type="text" name="firstName" id="firstName" class="form-control"
                  placeholder="שם פרטי">
                <input type="hidden" name="user_id" value="<?php echo e($user['id']); ?>">

              </div>
            </div>
            <div class="row">
              <div class="form-froup">
                
                <input value="<?php echo e($user['lastName']); ?>" type="text" name="lastName" id="lastName" class="form-control"
                  placeholder="שם משפחה">
              </div>
            </div>

            <div class="row">
            
              <div class="form-group">
                <div class="col-sm-8 form-control ">
                  <select name="city" id="city" class="custom-select">
                    <?php $__currentLoopData = $cps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if(old('city_id')==$c->id): ?> selected="selected" <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->city); ?>

              </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>


              <div class="row">
                <div class="form-group">
                  <input value="<?php echo e($user['phone']); ?>" type="text" class="phone" name="phone" id="phone" type="phone"
                    class="form-control" placeholder="מס פלאפון">
                </div>
              </div>

              <div class="row">
                <div class="form-group">
                  <input value="<?php echo e($user['email']); ?>" type="email" name="email" id="email" class="form-control"
                    placeholder="אימייל">
                  <div>
                    <div>

                      <div class="row">
                        <div class="form-group">
                          <input value="<?php echo e($user['password']); ?>" name="password" id="password" class="form-control"
                            type="password" placeholder="סיסמה">
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                          <div>
                            <div>
                              <div class="row">
                                <div class="form-group">
                                  <div id="permission" class="col-sm-8 form-control ">
                                    <select class="form-control" name="permission" id="permission">
                                      <option>Choose permission</option>
                                      <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php $__currentLoopData = $cps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option <?php if($u->permission_id==$p->id): ?> selected="selected" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        value="<?php echo e($p->id); ?>">
                                        <?php echo e($p->Kind); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </option>
                                    </select>
                                  </div>
                                </div>
                                <input type="submit" value="update Users" name="submit" class="btn btn-primary">
                                <a class="btn btn-secondary" href="<?php echo e(url('cms/users')); ?>">Cancel</a>
        </form>
      </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/edit_users.blade.php ENDPATH**/ ?>