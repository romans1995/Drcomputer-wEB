<?php $__env->startSection('main_content'); ?>
<div class="row">
  <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-12">
    <h4><?php echo e($content->ctitle); ?></h4>
    <p><?php echo $content->carticle; ?>}</p>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/content/content.blade.php ENDPATH**/ ?>