<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Add New Product</h1>

</div>
<div class="row">
  <div class="col-md-6">
    <form action="<?php echo e(url('cms/products')); ?>" method="POST" enctype="multipart/form-data" novalidate="novalidate"
      autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="form-froup">
        <label for="categorie_id">Category:</label>
        <select class="form-control" name="categorie_id" id="categorie-id">
          <option value="">Choose Categorie</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option <?php if(old('categorie_id')==$category['id']): ?> selected="selected" <?php endif; ?> value="<?php echo e($category['id']); ?>">
            <?php echo e($category['cname']); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span class="text-danger"><?php echo e($errors->first('categorie_id')); ?></span>
      </div>

      <div class="form-group">
        <label for="title">Product Title:</label>
        <input class="form-control source-text" type="text" name="title" id="title" value="<?php echo e(old('title')); ?>">
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
      </div>
      <div class="form-group">
        <label for="url">Product Url:</label>
        <input class="form-control target-text" type="text" name="url" id="url" value="<?php echo e(old('url')); ?>">
        <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
      </div>
      <div class="form-group">
        <label for="price">Product price:</label>
        <input class="form-control  " type="text" name="price" id="price" value="<?php echo e(old('price')); ?>">
        <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
      </div>

      <div class="form-group">
        <label for="article"> Description:</label>
        <textarea class="form-control" name="article" id="article" cols="30" rows="10"><?php echo e(old('article')); ?></textarea>
        <span class="text-danger"><?php echo e($errors->first('article')); ?></span>
      </div>

      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
        </div>
        <div class="custom-file">
          <input name="image" type="file" class="custom-file-input" id="inputGroupFile01"
            aria-describedby="inputGroupFileAddon01">
          <label class="custom-file-label" for="inputGroupFile01">
            Choose Product image</label>
        </div>
      </div>
      <div class="form-group">
        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
      </div>


      <input type="submit" value="Save product" name="submit" class="btn btn-primary">
      <a class="btn btn-secondary" href="<?php echo e(url('cms/products')); ?>">Cancel</a>

    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/create_product.blade.php ENDPATH**/ ?>