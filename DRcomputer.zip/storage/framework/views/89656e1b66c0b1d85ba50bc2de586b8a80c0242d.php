<?php $__env->startSection('main_content'); ?>


<style>
.action-button>li>a {

  font-size: 26px;
}



</style>
<?php if($products): ?>
<div class="short-by- f-right text-center">
    <span>Sort Price</span>
    <a href="<?php echo e(url('shop/'  .$curl . '?price=up')); ?>" class='btn btn-link'>From High to Low</a>|
<a href="<?php echo e(url('shop/'  .$curl . '?price=down')); ?>" class='btn btn-link' style='color:purple;'>From Low to High</a>
</div>




<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<h1 <?php echo e($products[0]->cname); ?>><?php echo e($product->ptitle); ?></h1>


<div class="col-md-4 col-sm-4 col-xs-12">
  

  <div class="product-item">
    <div class="product-img">

      <a href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>">
        <img hight="270" width="300" href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>"
          src="<?php echo e(asset('images/'.$product->pimage)); ?>" alt="<?php echo e($product->ptitle); ?> product image">
      </a>
    </div>
    <div class="product-info">

      <h6 class="product-title">
        <a href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>"><?php echo e($product->ptitle); ?> </a>
      </h6>
      <div class="pro-rating">
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star-half"></i></a>
      </div>
      <h3 class="pro-price">$<?php echo e($product->price); ?></h3>
      <ul class="action-button">
        <li>
          <a href="#" title="Wishlist"><i class="zmdi zmdi-favorite"></i></a>
        </li>
        <li>
          <a href="#" data-toggle="modal" data-target="#productModal" title="Quickview"><i
              class="zmdi zmdi-zoom-in"></i></a>
        </li>


        <li>
          <?php if(!Cart::get($product->id) ): ?>
          <a data-pid="<?php echo e($product->id); ?>" title="Add to cart" class="add-to-cart-btn"><i
              class="zmdi zmdi-shopping-cart-plus "></i></a>
        </li>
        <?php else: ?>
        <li>

          <a disabled="disabled" title="Add to cart" class="add-to-cart-btn"><i
              class="zmdi zmdi-shopping-cart-plus add-to-cart-btn">in
            cart</i></a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="row">
  <div class="col-12">
    <?php echo e($products->links()); ?>

  </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/content/products.blade.php ENDPATH**/ ?>