<?php $__env->startSection('main_content'); ?>


<div class="col-md-10 col-sm-12">
  <!-- Tab panes -->
  <div class="tab-content">
    <!-- shopping-cart start -->

    <div class="tab-pane active" id="shopping-cart">
      <div class="shopping-cart-content">
        <form action="#">
          <div class="table-content table-responsive mb-50">
            <?php if($cart): ?>
            <table class="text-center">
              <thead>
                <tr>
                  <th class="product-thumbnail">product</th>
                  <th class="product-price">price</th>
                  <th class="product-quantity">Quantity</th>
                  <th class="product-subtotal">total</th>
                  <th class="product-remove">remove</th>
                </tr>
              </thead>
              <tbody>
                <!-- tr -->
                <tr>
                  <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <td class="product-thumbnail">
                    <div class="pro-thumbnail-img">
                      <img src="<?php echo e(asset('images/'. $item['attributes']['image'])); ?>" alt="">
                    </div>
                    <div class="pro-thumbnail-info text-left">
                      <h6 class="product-title-2">
                        <a href="#"><?php echo e($item['name']); ?></a>
                      </h6>

                    </div>
                  </td>
                  <td class="product-price">ILS <?php echo e($item['price']); ?></td>
                  <td class="product-quantity">

                    <a href="<?php echo e(url('shop/update-cart?pid=' . $item['id'] .'&op=minus')); ?>"><i
                        class="fas fa-minus"></i></a>
                    <input type="text-center" size="1" value="<?php echo e($item['quantity']); ?>">
                    <a href="<?php echo e(url('shop/update-cart?pid=' .$item['id'] .'&op=plus')); ?>"> <i
                        class="fas fa-plus"></i></a></td>



          </div>

          </td>




          </td>
          <td class="product-subtotal">ILS <?php echo e($item['price'] * $item['quantity']); ?></td>
          <td class="product-remove">
            <a href="<?php echo e(url('shop/delete-item?pid=' . $item['id'])); ?>"><i class="zmdi zmdi-close"></i></a>
          </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>

          </table>
          <div class="col-md-6">
            <div class="payment-details box-shadow p-30 mb-50">
              <h6 class="widget-title border-left mb-20">payment details</h6>
              <table>

                <td class="order-total">Order Total</td>
                <td class="order-total-price">ILS <?php echo e(Cart::getTotal()); ?></td>
                </tr>
              </table>
            </div>
          </div>
      </div>

      <p><a href=" #" class="btn btn-primary"> !ORDER NOW!</a></p>


      <div class="d-flex flex-row-reverse bd-highlight">
        <a href="<?php echo e(url('shop/cart-clear')); ?>" class="btn btn-secondary p-2 bd-highlight">Clear Cart</a>
      </div>
      
      <?php else: ?>

      <h1><i>No items in cart....</i></h1>
      <?php endif; ?>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cart.blade.php ENDPATH**/ ?>