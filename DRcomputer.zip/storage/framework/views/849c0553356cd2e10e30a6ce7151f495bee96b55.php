<?php $__env->startSection('main_content'); ?>

<section class="engine"><a></a></section>
<section class="header3 cid-rqIRgyMGy6 mbr-parallax-background" id="header4-f">

  <div class="row">
    <div class="col-12">
      <h1 class="text-center">ברוכים הבאים</h1>
      <p class="text-center">פה תוכלו למצוא המון מידע על המחשב שלכם ואף לקנות מוצרים </p>
    </div>
  </div>
  <div class="mbr-overlay" style="opacity: 0.8; background-color: rgb(35, 35, 35);">
  </div>

  <div class="container">
    <div class="media-container-row">
      <div class="mbr-figure" style="width: 100%;">
        <img src="<?php echo e(asset('images/mbr-1014x743.jpg')); ?>" alt="Mobirise" title="">
      </div>

      <div class="media-content">
        <h1 class="mbr-section-title mbr-white pb-3 mbr-fonts-style display-1">
          Intro with Image
        </h1>

        <div class="mbr-section-text mbr-white pb-3 ">
          <p class="mbr-text mbr-fonts-style display-5">
            Full width intro with image background, color overlay and a picture on the left. You can easily change the
            size of image in block parameters.
          </p>
        </div>
        <div class="mbr-section-btn">
          <a class="btn btn-md btn-primary display-4" href="">LEARN MORE</a>
          <a class="btn btn-md btn-white-outline display-4" href="">LIVE DEMO</a>
        </div>
      </div>
    </div>
  </div>

</section>


</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/home.blade.php ENDPATH**/ ?>