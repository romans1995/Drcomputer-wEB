<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">orders</h1>
</div>
<?php if($orders): ?>
<table class="table table-bordered mt-5">
  <thead>
    <tr>
      <th>User</th>
      <th>Total</th>
      <th>Order Details</th>
      <th>Date</th>

    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($order->firstName); ?> <?php echo e($order->lastName); ?></td>
      <td></td>
      <td><?php echo e($order->total); ?></td>
      <td>

        <ul>
          <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


          <li><?php echo e($row['name']); ?> ,price: $<?php echo e($row['price']); ?>,Quantity: <?php echo e($row['quantity']); ?>

          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </td>


      <td><?php echo e(date('d/m/Y H:i:s',strtotime($order->created_at))); ?></td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/orders.blade.php ENDPATH**/ ?>