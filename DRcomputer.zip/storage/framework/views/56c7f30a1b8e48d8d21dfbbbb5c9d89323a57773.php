<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Add New Menu Link</h1>

</div>
<div class="row">
  <div class="col-md-6">
    <form action="<?php echo e(url('cms/menu')); ?>" method="POST" novalidate="novalidate" autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="link">Menu Link:</label>
        <input class="form-control source-text" type="text" name="link" id="link" value="<?php echo e(old('link')); ?>">
        <span class="text-danger"><?php echo e($errors->first('link')); ?></span>
      </div>
      <div class="form-group">
        <label for="link">Menu Link Url:</label>
        <input class="form-control target-text" type="text" name="url" id="url" value="<?php echo e(old('url')); ?>">
        <span class="text-danger"><?php echo e($errors->first('url')); ?></span>
      </div>
      <div class="form-group">
        <label for="link">Menu Link Title:</label>
        <input class="form-control " type="text" name="title" id="title" value="<?php echo e(old('title')); ?>">
        <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
      </div>
      <input type="submit" value="save Menu" name="submit" class="btn btn-primary">
      <a class="btn btn-secondary" href="<?php echo e(url('cms/menu')); ?>">Cancel</a>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/create_menu.blade.php ENDPATH**/ ?>