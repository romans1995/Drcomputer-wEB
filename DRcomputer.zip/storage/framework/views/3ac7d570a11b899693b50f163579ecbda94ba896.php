<?php $__env->startSection('main_content'); ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1 <?php echo e($products[0]->cname); ?>><?php echo e($product->ptitle); ?></h1>

<div class="col-md-4 col-sm-4 col-xs-12">
  <div class="product-item">
    <div class="product-img">

      <a href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>">
        <img hight="270" width="300" href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>"
          src="<?php echo e(asset('images/'.$product->pimage)); ?>" alt="<?php echo e($product->ptitle); ?> product image">
      </a>
    </div>
    <div class="product-info">

      <h6 class="product-title">
        <a href="<?php echo e(url('shop/' .$curl .'/' .$product->purl)); ?>"><?php echo e($product->ptitle); ?> </a>
      </h6>
      <div class="pro-rating">
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star"></i></a>
        <a href="#"><i class="zmdi zmdi-star-half"></i></a>
      </div>
      <h3 class="pro-price">$<?php echo e($product->price); ?></h3>
      <ul class="action-button">
        <li>
          <a href="#" title="Wishlist"><i class="zmdi zmdi-favorite"></i></a>
        </li>
        <li>
          <a href="#" data-toggle="modal" data-target="#productModal" title="Quickview"><i
              class="zmdi zmdi-zoom-in"></i></a>
        </li>


        <li>
          <?php if(!Cart::get($product->id) ): ?>
          <a data-pid="<?php echo e($product->id); ?>" title="Add to cart" class="add-to-cart-btn"><i
              class="zmdi zmdi-shopping-cart-plus "></i></a>
        </li>
        <?php else: ?>
        <li>

          <a disabled="disabled" title="Add to cart" class="add-to-cart-btn"><i
              class="zmdi zmdi-shopping-cart-plus add-to-cart-btn"></i>in
            cart</a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/products.blade.php ENDPATH**/ ?>