<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">Categories</h1>
</div>
<p><a href="<?php echo e(url('cms/categories/create')); ?>" class="btn btn-primary"><i class="fas fa-plus-circle"></i>Add new
    Category</a>
</p>
<?php if($categories): ?>
<table class="table table-bordered mt-5">
  <thead>
    <tr>
      <th>category title</th>
      <th>Category Lead Image</th>
      <th>Updated At</th>
      <th>Operations</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($category['cname']); ?></td>
      <td><img width="50" src="<?php echo e(asset('images/'.$category['cimage'])); ?>"></td>
      <td><?php echo e(date('d/m/Y H:i:s',strtotime($category['updated_at']))); ?></td>
      <td>
        <a href="<?php echo e(url('cms/categories/' . $category['id'] . '/edit')); ?>"><i class="fas fa-pen"></i>Edit</a>|
        <a href="<?php echo e(url('cms/categories/'.$category['id'])); ?>"><i class="fas fa-eraser"></i>Delete</a>

      </td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/categories.blade.php ENDPATH**/ ?>