<?php $__env->startSection('cms_content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

  <h1 class="h2">are you sure you want to delete ?</h1>
</div>
<div class="row">
  <div class="col-md-6">
    <form action="<?php echo e(url('cms/content/' . $item_id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo e(method_field('DELETE')); ?>

      <input type="submit" value="DELETE" name="submit" class="btn btn-danger">
      <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-secondary">CANCEL</a>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DRcomputer\resources\views/cms/delete_content.blade.php ENDPATH**/ ?>